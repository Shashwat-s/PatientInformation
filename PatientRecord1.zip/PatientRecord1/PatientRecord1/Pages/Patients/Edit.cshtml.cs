using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace PatientRecord1.Pages.Patients
{
    public class EditcshtmlModel : PageModel
    {
        public PatientInfo patientInfo = new PatientInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=localhost;Initial Catalog=patientrecord;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sqlC = "SELECT * FROM patients_record WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sqlC, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                patientInfo.id = "" + reader.GetInt32(0);
                                patientInfo.name = reader.GetString(1);
                                patientInfo.email = reader.GetString(2);
                                patientInfo.phone = reader.GetString(3);
                                patientInfo.address = reader.GetString(4);
                                patientInfo.diseases = reader.GetString(5);
                                patientInfo.aadhar_number = reader.GetString(6);
                            }
                        }
                        
                    }
                }
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
            }
        }

        public void OnPost()
        {
            patientInfo.id = Request.Form["id"];
            patientInfo.name = Request.Form["name"];
            patientInfo.email = Request.Form["email"];
            patientInfo.phone = Request.Form["phone"];
            patientInfo.address = Request.Form["address"];
            patientInfo.diseases = Request.Form["disease"];
            patientInfo.aadhar_number = Request.Form["aadhar_number"];

            if (patientInfo.name.Length == 0 || patientInfo.email.Length == 0 || patientInfo.phone.Length == 0 ||
                patientInfo.address.Length == 0 || patientInfo.diseases.Length == 0 ||
                patientInfo.aadhar_number.Length == 0)
            {
                errorMessage = "Fill all fields";
                return;
            }

            try
            {
                String connectionString = "Data Source=localhost;Initial Catalog=patientrecord;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sqlC = "UPDATE patients_record " +
                                  "SET name=@name, email=@email, phone=@phone, address=@address, diseases=@diseases, aadhar_number=@aadhar_number "+
                                  "WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sqlC, connection))
                    {
                        command.Parameters.AddWithValue("@name", patientInfo.name);
                        command.Parameters.AddWithValue("@email", patientInfo.email);
                        command.Parameters.AddWithValue("@phone", patientInfo.phone);
                        command.Parameters.AddWithValue("@address", patientInfo.address);
                        command.Parameters.AddWithValue("@diseases", patientInfo.diseases);
                        command.Parameters.AddWithValue("@aadhar_number", patientInfo.aadhar_number);
                        command.Parameters.AddWithValue("@id", patientInfo.id);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
                return;
            }

            Response.Redirect("/Patients/Index");
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace PatientRecord1.Pages.Patients
{
    public class AddCreateModel : PageModel
    {
        public PatientInfo patientInfo = new PatientInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            patientInfo.name = Request.Form["name"];
            patientInfo.email = Request.Form["email"];
            patientInfo.phone = Request.Form["phone"];
            patientInfo.address = Request.Form["address"];
            patientInfo.diseases = Request.Form["disease"];
            patientInfo.aadhar_number = Request.Form["aadhar_number"];

            if (patientInfo.name.Length == 0 || patientInfo.email.Length == 0 || patientInfo.phone.Length == 0 ||
                patientInfo.address.Length == 0 || patientInfo.diseases.Length == 0 ||
                patientInfo.aadhar_number.Length == 0)
            {
                errorMessage = "Fill all fields";
                return;
            }

            //save the data
            try
            {
                String connectionString = "Data Source=localhost;Initial Catalog=patientrecord;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sqlC = "INSERT INTO patients_record " +
                                  "(name, email, phone, address, diseases, aadhar_number) VALUES " +
                                  "(@name, @email, @phone, @address, @diseases, @aadhar_number);";
                    using (SqlCommand command = new SqlCommand(sqlC, connection))
                    {
                        command.Parameters.AddWithValue("@name", patientInfo.name);
                        command.Parameters.AddWithValue("@email", patientInfo.email);
                        command.Parameters.AddWithValue("@phone", patientInfo.phone);
                        command.Parameters.AddWithValue("@address", patientInfo.address);
                        command.Parameters.AddWithValue("@diseases", patientInfo.diseases);
                        command.Parameters.AddWithValue("@aadhar_number", patientInfo.aadhar_number);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
                return;
            }

            patientInfo.name = "";
            patientInfo.email = "";
            patientInfo.phone = "";
            patientInfo.address = "";
            patientInfo.diseases = "";
            patientInfo.aadhar_number = "";

            successMessage = "Patient added successfully";
            Response.Redirect("/Patients/Index");
        }
    }
}
